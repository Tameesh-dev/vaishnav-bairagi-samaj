/* वैष्णव बैरागी समाज — site scripts */
(function () {
  "use strict";

  /* footer year */
  var yr = document.getElementById("year");
  if (yr) yr.textContent = new Date().getFullYear();

  /* mobile nav */
  var toggle = document.getElementById("navToggle");
  var nav = document.getElementById("siteNav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () { nav.classList.toggle("open"); });
    nav.addEventListener("click", function (e) {
      if (e.target.closest("a")) nav.classList.remove("open");
    });
  }

  /* reveal on scroll */
  var io = "IntersectionObserver" in window
    ? new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add("visible"); io.unobserve(en.target); }
        });
      }, { threshold: 0.12 })
    : null;
  document.querySelectorAll(".reveal").forEach(function (el) {
    if (io) io.observe(el); else el.classList.add("visible");
  });

  /* animated counters */
  function animateCount(el) {
    var target = parseInt(el.getAttribute("data-count"), 10) || 0;
    var dur = 1400, t0 = null;
    function tick(now) {
      if (!t0) t0 = now;
      var p = Math.min((now - t0) / dur, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(target * eased).toLocaleString("en-IN");
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  var seen = typeof WeakSet !== "undefined" ? new WeakSet() : null;
  var cio = "IntersectionObserver" in window
    ? new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting && (!seen || !seen.has(en.target))) {
            if (seen) seen.add(en.target);
            animateCount(en.target);
            cio.unobserve(en.target);
          }
        });
      }, { threshold: 0.4 })
    : null;
  document.querySelectorAll(".stat-num[data-count]").forEach(function (el) {
    if (cio) cio.observe(el); else animateCount(el);
  });

  /* ---------- member directory ---------- */
  var grid = document.getElementById("memberGrid");
  if (!grid) return;

  var searchInput = document.getElementById("searchInput");
  var stateFilter = document.getElementById("stateFilter");
  var placeFilter = document.getElementById("placeFilter");
  var professionFilter = document.getElementById("professionFilter");
  var resultCount = document.getElementById("resultCount");
  var emptyState = document.getElementById("emptyState");

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }

  function pinSvg() {
    var svgNS = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(svgNS, "svg");
    svg.setAttribute("viewBox", "0 0 20 20");
    svg.setAttribute("width", "14"); svg.setAttribute("height", "14");
    svg.setAttribute("fill", "none");
    var p1 = document.createElementNS(svgNS, "path");
    p1.setAttribute("d", "M10 18s6-5.2 6-9.5A6 6 0 0 0 4 8.5C4 12.8 10 18 10 18z");
    p1.setAttribute("stroke", "currentColor"); p1.setAttribute("stroke-width", "1.6");
    var c = document.createElementNS(svgNS, "circle");
    c.setAttribute("cx", "10"); c.setAttribute("cy", "8.5"); c.setAttribute("r", "2.2");
    c.setAttribute("stroke", "currentColor"); c.setAttribute("stroke-width", "1.6");
    svg.appendChild(p1); svg.appendChild(c);
    return svg;
  }

  function renderMembers(list) {
    grid.innerHTML = "";
    list.forEach(function (m) {
      var card = el("article", "member-card");
      var initial = (m.name || " ").trim().charAt(0);
      card.appendChild(el("div", "member-avatar", initial));
      card.appendChild(el("h3", "member-name", m.name));
      var place = el("p", "member-place");
      place.appendChild(pinSvg());
      place.appendChild(document.createTextNode(
        " " + m.village + (m.district ? ", " + m.district : "")));
      card.appendChild(place);
      var prof = (m.profession || "").split("/")[0].trim();
      card.appendChild(el("span", "member-prof", prof));
      if (m.details) {
        var d = el("p", "member-details");
        d.style.cssText = "color:#57705F;font-size:.85rem;margin-top:.6rem;";
        d.textContent = m.details;
        card.appendChild(d);
      }
      grid.appendChild(card);
    });
  }

  var timer = null;
  function fetchMembers() {
    var params = new URLSearchParams();
    if (searchInput.value.trim()) params.set("q", searchInput.value.trim());
    if (stateFilter.value) params.set("state", stateFilter.value);
    if (placeFilter && placeFilter.value) params.set("place", placeFilter.value);
    if (professionFilter.value) params.set("profession", professionFilter.value);
    resultCount.textContent = "खोजा जा रहा है…";
    fetch("/api/members?" + params.toString(), { headers: { Accept: "application/json" } })
      .then(function (r) { return r.json(); })
      .then(function (list) {
        resultCount.innerHTML = "कुल <b>" + list.length.toLocaleString("en-IN") +
          "</b> सदस्य मिले · <b>" + list.length + "</b> members found";
        emptyState.hidden = list.length !== 0;
        renderMembers(list);
      })
      .catch(function () {
        resultCount.textContent = "लोड करने में समस्या — पुनः प्रयास करें।";
      });
  }
  function debounced() { clearTimeout(timer); timer = setTimeout(fetchMembers, 280); }

  searchInput.addEventListener("input", debounced);
  stateFilter.addEventListener("change", fetchMembers);
  if (placeFilter) placeFilter.addEventListener("change", fetchMembers);
  professionFilter.addEventListener("change", fetchMembers);
  fetchMembers();
})();
